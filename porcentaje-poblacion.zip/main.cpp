/******************************************************************************
Realice un programa que permita dar como salida la poblaciC3n de dos paC-ses (a y b), teniendo en cuenta para tal propC3sito lo siguiente:

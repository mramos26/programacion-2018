/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>
#include<math.h>
using namespace std;

int main(){
    
   float X, Y, resultado = 0;
    
    cout<<"dame la base X: ";
    cin>>X;
    
    cout<<"dame el exponente Y:  ";
    cin>>Y;
    
 
    resultado = (pow(X,2)-0); 
    
    cout<<"el resultado es:  "<<resultado<<endl;
    
    
    
    
    
    return 0;
}